const http = require('http');
const https = require('https');
const url = require("url");
const fs = require("fs");
const port = 3000;
const server = http.createServer();
const querystring = require("querystring");


const {client_id, client_server, response_type, scope, state, grant_type} = require('./auth/credentials.json');
const redirect_uri = "https://replit.com/@ArchieC/CS355-Final-Project#apiCredentials/credentials.json";


server.on("listening", listeningHandler);
server.listen(port);
function listeningHandler(){
	console.log(`Now Listening on Port ${port}`);
}


server.on("request", connectionHandler);
function connectionHandler(req, res){
	console.log(`New Request for ${req.url} from ${req.socket.remoteAddress}`);
	if(req.url === "/"){
		const page = fs.createReadStream("html/index.html");
		res.writeHead(200, {"Content-Type" : "text/html"});
		page.pipe(res);
	}
	else if(req.url.startsWith("/search")){
		let {playlistNumber, userID} = url.parse(req.url, true).query;
		getPlaylist(playlistNumber, userID, res);
		requestUserPermissions(res);
	}
	else if(req.url.startsWith("/callback")){
		const {code, state} = url.parse(req.url, true).query;
		sendAccessTokenRequest(code, state, res);
	}
	else{
		res.writeHead(404, {"Content-Type": "text/html"});
    res.end(`<h1>404 Not Found</h1>`);
	}
}

function getPlaylist(playlistNumber, userID, res){
	const playlistEndpoint = `https://openwhyd.org/u/${userID}/playlist/${playlistNumber}?format=json&limit=10000`;
	https.request(playlistEndpoint, {method:"GET"}, processStream).end();
	function processStream(playlistStream){
		let playlistData = "";
		playlistStream.on("data", dataChunk => playlistData += dataChunk);
		playlistStream.on("end", () => displayPlaylist(playlistData, res));
	}
}

function displayPlaylist(playlistData, res){
	let playlist = JSON.parse(playlistData);
	let results = playlist.map(formatPlaylist).join('');
	results = `<h1>Your Playlist:</h1>${results}`
	res.writeHead(200, {"Content-Type": "text/html"});
	res.end(results);

	function formatPlaylist({name}){
		return `{\n${name}\n}`;
	}
	return `${name}`;
}
function requestUserPermissions(res){
	let auth_endpoint = "https://accounts.spotify.com/authorize";
	let uri = querystring.stringify({client_id, response_type, scope, state, redirect_uri});
	console.log(`${auth_endpoint}?${uri}`);
	res.writeHead(302, {Location: `${auth_endpoint}?${uri}`}).end();
}
function sendAccessTokenRequest(code, state, res){
	const tokenEndpoint = "https://accounts.spotify.com/api/token";
	const post_data = querystring.stringify({code, state});
	console.log(post_data);
	let options = {
		method: "POST",
		headers:{
			"Content-Type":"application/x-www-form-urlencoded"
		}
	}
	https.request(tokenEndpoint, options, process_stream(receive_access_token, res)).end(post_data);
}